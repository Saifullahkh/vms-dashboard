<footer class="footer-main mt-auto">
    <div class="text-center py-2 small">
        © 2025 CHAMPS VMA. All Rights Reserved.
    </div>
</footer>
<script src="script.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>