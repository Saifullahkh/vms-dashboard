<?php
session_start();

if (!isset($_SESSION['user'])) {
  header("Location: ./auth/login.php");
  exit();
}
?>
<?php
  include("header_meta.php");
  ?>

<div id="dashboard-page">

  <?php
  include("sidebar.php");
  ?>
  <div id="main-wrapper">
    <?php
    include("nav.php");

    ?>

    <div class="px-4 px-md-5 py-4">
      <div id="dashboard-view" class="fade-in">
        <div class="row g-4 mb-5">
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./vehicle/vehicle-mngt.php" style="text-decoration: none; color: inherit;">
                <div class="icon-box bg-primary-subtle text-primary mx-auto mb-3">
                  <i class="fas fa-bus-alt"></i>
                </div>
                <h5 class="fw-bold">Vehicle Management</h5>
                <p class="small text-white">
                  Manage fleet, drivers & history
                </p>
            </div>
            </a>
          </div>
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./incident-intervention/incident-intervention.php"
                style="text-decoration: none; color: inherit ">
                <div class="icon-box bg-success-subtle text-success mx-auto mb-3">
                  <i class="fas fa-tools"></i>
                </div>
                <h5 class="fw-bold">Incident & Intervention</h5>
                <p class="small text-white">Repairs & reports</p>
              </a>

            </div>
          </div>
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./goods-inspections/goods-inspection.php" style="text-decoration: none; color: inherit ">
                <div class="icon-box bg-blue-light mx-auto mb-3">
                  <i class="fas fa-clipboard-check "></i>
                </div>
                <h5 class="fw-bold">On Board Goods Inspection</h5>
                <p class="small text-white">Verification of cargo and inventory logs</p>
              </a>

            </div>
          </div>
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./vehicle-tracking/vehicle-tracking.php" style="text-decoration: none; color: inherit ">
                <div class="icon-box bg-warning-subtle text-warning mx-auto mb-3">
                  <i class="fas fa-location-dot"></i>
                </div>
                <h5 class="fw-bold">Vehicle Tracking</h5>
                <p class="small text-white">Real-time GPS status</p>
              </a>
            </div>
          </div>
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./asset-enumeration/asset-enumeration.php" style="text-decoration: none; color: inherit">
                <div class="icon-box bg-info-subtle text-info mx-auto mb-3">
                  <i class="fas fa-boxes-stacked"></i>
                </div>
                <h5 class="fw-bold">Asset Enumeration</h5>
                <p class="small text-white">Stock & inventory</p>
              </a>
            </div>
          </div>
          <div class="col-xl-4 col-md-6">
            <div class="action-card">
              <a href="./report-analytics/report-analytics.php" style="text-decoration: none; color: inherit ">
                <div class="icon-box bg-success-subtle text-success mx-auto mb-3">
                  <i class="fas fa-chart-line"></i>
                </div>
                <h5 class="fw-bold">Reports & Analytics</h5>
                <p class="small text-white">Data insights & performance</p>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
    include("footer.php");
    ?>
  </div>
</div>