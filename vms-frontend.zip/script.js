(function () {
  const sidebarStatus = localStorage.getItem("sidebarState");
  if (sidebarStatus === "closed") {
    document.documentElement.classList.add("sidebar-hidden");
  }
})();

document.addEventListener("DOMContentLoaded", function () {
  const sidebar = document.getElementById("sidebar");
  const toggleIcon = document.getElementById("toggleIcon");

  // 1. Agar head wali script ne class lagayi thi, toh sidebar ko sync karein
  if (document.documentElement.classList.contains("sidebar-hidden")) {
    sidebar.classList.add("active");
    if (toggleIcon) toggleIcon.className = "fas fa-bars-staggered";
  }

  // 2. Thori der baad transitions on karein taaki user ko jhatka na lage
  setTimeout(() => {
    document.body.classList.add("ready");
  }, 100);

  // 3. Baqi aapka purana Click Event Logic...
  document
    .getElementById("sidebarToggle")
    .addEventListener("click", function () {
      sidebar.classList.toggle("active");
      const isClosed = sidebar.classList.contains("active");

      // State save karein
      localStorage.setItem("sidebarState", isClosed ? "closed" : "open");

      // Icon change
      if (isClosed) {
        document.documentElement.classList.add("sidebar-hidden");
        toggleIcon.className = "fas fa-bars-staggered";
      } else {
        document.documentElement.classList.remove("sidebar-hidden");
        toggleIcon.className = "fas fa-bars";
      }
    });
});
