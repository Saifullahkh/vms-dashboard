<?php
// Session check for security
session_start();
if (!isset($_SESSION['user'])) {
    // Auth folder bhi baahar hai, isliye ../ use kiya
    header("Location: ../auth/login.php");
    exit();
}

// Ek folder peeche (root par) jaane ke liye ../ use karein
?>

<?php
include("../header_meta.php");
?>

<div id="dashboard-page">

    <?php
    include("../sidebar.php");
    ?>
    <div id="main-wrapper">
        <?php
        include("../nav.php");

        ?>

        <!-- incident and intervention -->
        <div id="incidents-mgmt-view" class="px-4 px-md-5 py-4">
            <div class="row align-items-center mb-3">
                <div class="col-md-8">
                    <h2 class="fw-bold text-dark tracking-tight mb-1">Incident & Intervention</h2>
                </div>
            </div>

            <div class="row g-4">
                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./impoundment.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-primary-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-primary text-white me-4">
                                    <i class="fas fa-gavel fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">08</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Impoundment</p>
                                </div>
                                <div class="ms-auto">
                                    <span
                                        class="badge rounded-pill bg-light text-primary fw-bold p-2 small">Legal</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./vehicle-breakdown.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-warning-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-warning text-white me-4">
                                    <i class="fas fa-car-crash fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">14</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Breakdown</p>
                                </div>
                                <div class="ms-auto">
                                    <span
                                        class="badge rounded-pill bg-light text-warning fw-bold p-2 small">Repair</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./illegal-detention.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-dark-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-dark text-white me-4">
                                    <i class="fas fa-handcuffs fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">03</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Illegal Detention</p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge rounded-pill bg-light text-dark fw-bold p-2 small">Alert</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./accident.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-danger-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-danger text-white me-4">
                                    <i class="fas fa-ambulance fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">05</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Accident</p>
                                </div>
                                <div class="ms-auto">
                                    <span
                                        class="badge rounded-pill bg-light text-danger fw-bold p-2 small">Urgent</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./vehicle-bugged-down.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-success-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-success text-white me-4">
                                    <i class="fas fa-truck-pickup fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">11</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Bugged Down</p>
                                </div>
                                <div class="ms-auto">
                                    <span
                                        class="badge rounded-pill bg-light text-success fw-bold p-2 small">Recovery</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./route-diversion.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-info-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-info text-white me-4">
                                    <i class="fas fa-route fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">07</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Route Diversion</p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge rounded-pill bg-light text-info fw-bold p-2 small">Traffic</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./driver-misconduct.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-orange-subtle"
                                style="background-color: rgba(253, 126, 20, 0.1);"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-orange text-white me-4" style="background-color: #fd7e14;">
                                    <i class="fas fa-user-slash fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">09</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Driver Misconduct</p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge rounded-pill bg-light text-warning fw-bold p-2 small">HR</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

                <div class="col-xl-4 col-md-6">
                    <a class="text-decoration-none metric-card border-0 rounded-5 shadow-hover h-100 d-block"
                        href="./illegal-haulage.php">
                        <div class="card-body p-4 position-relative overflow-hidden">
                            <div class="metric-shape bg-warning-subtle"></div>
                            <div class="d-flex align-items-center position-relative">
                                <div class="icon-glow bg-warning text-white me-4">
                                    <i class="fas fa-boxes fa-lg"></i>
                                </div>
                                <div>
                                    <h3 class="fw-bolder mb-0 text-dark">22</h3>
                                    <p class="text-muted small fw-bold mb-0 opacity-75">Illegal Haulage</p>
                                </div>
                                <div class="ms-auto">
                                    <span class="badge rounded-pill bg-light text-danger fw-bold p-2 small">Fine</span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>

            </div>

            <div class="row g-4 mt-2 ">
                <div class="col-xl-8">
                    <div class="card border-0 rounded-5 shadow-sm h-100">
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-4">
                                <div>
                                    <h5 class="fw-bold mb-1">Incident Analysis</h5>
                                    <p class="text-muted small mb-0">Monthly breakdown of reported issues</p>
                                </div>
                                <div class="dropdown">
                                    <button class="btn btn-light btn-sm rounded-pill px-3 border shadow-none"
                                        type="button">
                                        Year 2026 <i class="fas fa-filter ms-1 small"></i>
                                    </button>
                                </div>
                            </div>
                            <div style="height: 320px;">
                                <canvas id="incidentBarChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4">
                    <div class="card border-0 rounded-5 shadow-sm h-100">
                        <div class="card-body p-4">
                            <div class="mb-4">
                                <h5 class="fw-bold mb-1">Issue Distribution</h5>
                                <p class="text-muted small mb-0">Incidents by category</p>
                            </div>
                            <div style="height: 280px;">
                                <canvas id="incidentPolarChart"></canvas>
                            </div>
                            <div class="mt-4">
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="small text-muted">Most Frequent:</span>
                                    <span class="small fw-bold text-danger">Accidents (22%)</span>
                                </div>
                                <div class="progress" style="height: 6px;">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: 22%"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>

<?php
// Ek folder peeche ja kar footer include karein
include("../footer.php");
?>